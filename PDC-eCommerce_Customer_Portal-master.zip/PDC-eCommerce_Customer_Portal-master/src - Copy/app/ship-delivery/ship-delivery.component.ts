import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ship-delivery',
  templateUrl: './ship-delivery.component.html',
  styleUrls: ['./ship-delivery.component.css']
})
export class ShipDeliveryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
