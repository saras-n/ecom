import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-return-exchange',
  templateUrl: './return-exchange.component.html',
  styleUrls: ['./return-exchange.component.css']
})
export class ReturnExchangeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
